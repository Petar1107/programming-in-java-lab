package com.oss.lecture5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lecture5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
