package com.oss.lecture5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lecture5Application {
	public static void main(String[] args) {
		SpringApplication.run(Lecture5Application.class, args);
	}

}
